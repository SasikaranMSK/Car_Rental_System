using Microsoft.EntityFrameworkCore;
using CarRentalSystemSeparation.Common.Data;
using CarRentalSystemSeparation.Areas.Customer.Models;
using CarRentalSystemSeparation.Common.Enums;
using Microsoft.Data.SqlClient;

namespace CarRentalSystemSeparation.Areas.Customer.Repositories
{
 
  
    public interface ICustomerRepository
    {
        Task<IEnumerable<Models.Customer>> GetAllAsync();
        Task<Models.Customer?> GetByIdAsync(int id);
        Task<Models.Customer?> GetByUserIdAsync(int userId);
        Task<Models.Customer> CreateAsync(Models.Customer customer);
        Task<Models.Customer> UpdateAsync(Models.Customer customer);
        Task<bool> DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
    }

  
    public class CustomerRepository : ICustomerRepository
    {
        private readonly ApplicationDbContext _context;

        public CustomerRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Models.Customer>> GetAllAsync()
        {
            try
            {
                return await _context.Customers
                    .Include(c => c.User)
                    .OrderBy(c => c.User.FirstName)
                    .ThenBy(c => c.User.LastName)
                    .ToListAsync();
            }
            catch (SqlException ex) when (ex.Message.Contains("Invalid object name 'Customers'"))
            {
                // Table doesn't exist yet - return empty list so app can continue
                return Enumerable.Empty<Models.Customer>();
            }
            catch
            {
                return Enumerable.Empty<Models.Customer>();
            }
        }

        public async Task<Models.Customer?> GetByIdAsync(int id)
        {
            try
            {
                return await _context.Customers
                    .Include(c => c.User)
                    .FirstOrDefaultAsync(c => c.Id == id);
            }
            catch (SqlException ex) when (ex.Message.Contains("Invalid object name 'Customers'"))
            {
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<Models.Customer?> GetByUserIdAsync(int userId)
        {
            try
            {
                return await _context.Customers
                    .Include(c => c.User)
                    .FirstOrDefaultAsync(c => c.UserId == userId);
            }
            catch (SqlException ex) when (ex.Message.Contains("Invalid object name 'Customers'"))
            {
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<Models.Customer> CreateAsync(Models.Customer customer)
        {
            customer.CreatedAt = DateTime.UtcNow;
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return customer;
        }

        public async Task<Models.Customer> UpdateAsync(Models.Customer customer)
        {
            customer.UpdatedAt = DateTime.UtcNow;
            _context.Customers.Update(customer);
            await _context.SaveChangesAsync();
            return customer;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            try
            {
                var customer = await _context.Customers.FindAsync(id);
                if (customer == null)
                    return false;

                _context.Customers.Remove(customer);
                await _context.SaveChangesAsync();
                return true;
            }
            catch (SqlException ex) when (ex.Message.Contains("Invalid object name 'Customers'"))
            {
                return false;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> ExistsAsync(int id)
        {
            try
            {
                return await _context.Customers.AnyAsync(c => c.Id == id);
            }
            catch (SqlException ex) when (ex.Message.Contains("Invalid object name 'Customers'"))
            {
                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}