using AutoMapper;
using CarRentalSystemSeparation.Areas.Customer.Models;
using CarRentalSystemSeparation.Areas.Customer.DTOs;
using CarRentalSystemSeparation.Areas.Customer.ViewModels;
using CarRentalSystemSeparation.Areas.Customer.Repositories;
using CarRentalSystemSeparation.Areas.Admin.Repositories;

namespace CarRentalSystemSeparation.Areas.Customer.Services
{
    public interface ICustomerService
    {
        Task<IEnumerable<CustomerListDTO>> GetAllCustomersAsync();
        Task<CustomerDTO?> GetCustomerByIdAsync(int id);
        Task<CustomerDTO?> GetCustomerByUserIdAsync(int userId);
        Task<CustomerDTO?> CreateCustomerAsync(CustomerViewModel viewModel);
        Task<CustomerDTO?> UpdateCustomerAsync(int id, CustomerViewModel viewModel);
        Task<bool> DeleteCustomerAsync(int id);
    }

    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IMapper _mapper;
        private readonly IUserRepository _userRepository;

        public CustomerService(ICustomerRepository customerRepository, IMapper mapper, IUserRepository userRepository)
        {
            _customerRepository = customerRepository;
            _mapper = mapper;
            _userRepository = userRepository;
        }

        public async Task<IEnumerable<CustomerListDTO>> GetAllCustomersAsync()
        {
            var customers = await _customerRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<CustomerListDTO>>(customers);
        }

        public async Task<CustomerDTO?> GetCustomerByIdAsync(int id)
        {
            var customer = await _customerRepository.GetByIdAsync(id);
            if (customer == null)
                return null;

            // Ensure User navigation is populated
            if (customer.User == null)
            {
                var user = await _userRepository.GetByIdAsync(customer.UserId);
                if (user != null)
                {
                    customer.User = user;
                }
            }

            return _mapper.Map<CustomerDTO>(customer);
        }

        public async Task<CustomerDTO?> GetCustomerByUserIdAsync(int userId)
        {
            var customer = await _customerRepository.GetByUserIdAsync(userId);
            if (customer == null)
                return null;

            if (customer.User == null)
            {
                var user = await _userRepository.GetByIdAsync(customer.UserId);
                if (user != null)
                {
                    customer.User = user;
                }
            }

            return _mapper.Map<CustomerDTO>(customer);
        }

        public async Task<CustomerDTO?> CreateCustomerAsync(CustomerViewModel viewModel)
        {
            // Business rule: Check if customer already exists for this user
            var existingCustomer = await _customerRepository.GetByUserIdAsync(viewModel.UserId);
            if (existingCustomer != null)
                return null;

            var customer = _mapper.Map<Models.Customer>(viewModel);
            var createdCustomer = await _customerRepository.CreateAsync(customer);

            // Populate User navigation for mapping
            if (createdCustomer.User == null)
            {
                var user = await _userRepository.GetByIdAsync(createdCustomer.UserId);
                if (user != null) createdCustomer.User = user;
            }

            return _mapper.Map<CustomerDTO>(createdCustomer);
        }

        public async Task<CustomerDTO?> UpdateCustomerAsync(int id, CustomerViewModel viewModel)
        {
            var existingCustomer = await _customerRepository.GetByIdAsync(id);
            if (existingCustomer == null)
                return null;

            // Update customer properties
            existingCustomer.Phone = viewModel.Phone;
            existingCustomer.Address = viewModel.Address;
            existingCustomer.City = viewModel.City;
            existingCustomer.State = viewModel.State;
            existingCustomer.ZipCode = viewModel.ZipCode;
            existingCustomer.DateOfBirth = viewModel.DateOfBirth;
            existingCustomer.LicenseNumber = viewModel.LicenseNumber;
            existingCustomer.LicenseExpiry = viewModel.LicenseExpiry;

            var updated = await _customerRepository.UpdateAsync(existingCustomer);

            if (updated.User == null)
            {
                var user = await _userRepository.GetByIdAsync(updated.UserId);
                if (user != null) updated.User = user;
            }

            return _mapper.Map<CustomerDTO>(updated);
        }

        public async Task<bool> DeleteCustomerAsync(int id)
        {
            return await _customerRepository.DeleteAsync(id);
        }
    }
}