﻿using MailKit.Security;
using MimeKit;
using NETCore.MailKit.Core;
using MailKit.Net.Smtp;


namespace CarRentalSystemSeparation.Areas.Customer.Services
{
    public class EmailService : Areas.Customer.Services.IEmailService
    {
        private readonly string smtpServer;
        private readonly int smtpPort;
        private readonly string smtpUser;
        private readonly string smtpPass;

        public EmailService(IConfiguration configuration)
        {
            smtpServer = configuration["Authentication:EmailSettings:SmtpServer"];
            smtpPort = int.Parse(configuration["Authentication:EmailSettings:SmtpPort"] ?? "587");
            smtpUser = configuration["Authentication:EmailSettings:SmtpUser"];
            smtpPass = configuration["Authentication:EmailSettings:SmtpPass"];

            // SmtpUser சரிபார்ப்பு
            if (string.IsNullOrEmpty(smtpUser))
            {
                throw new ArgumentNullException(nameof(smtpUser), "SMTP User email address is not configured in appsettings.json.");
            }
        }

        public async Task SendAsync(string toEmail, string subject, string body)
        {
            if (string.IsNullOrEmpty(toEmail))
            {
                throw new ArgumentNullException(nameof(toEmail), "Recipient email address cannot be null or empty.");
            }

            var email = new MimeMessage();
            email.From.Add(MailboxAddress.Parse(smtpUser));
            email.To.Add(MailboxAddress.Parse(toEmail));
            email.Subject = subject;
            email.Body = new TextPart(MimeKit.Text.TextFormat.Html) { Text = body };

            using var smtp = new SmtpClient();
            await smtp.ConnectAsync(smtpServer, smtpPort, SecureSocketOptions.StartTls);
            await smtp.AuthenticateAsync(smtpUser, smtpPass);
            await smtp.SendAsync(email);
            await smtp.DisconnectAsync(true);
        }
    }
}