﻿using System.Threading.Tasks;

namespace CarRentalSystemSeparation.Areas.Customer.Services
{
    public interface IEmailService
    {
        Task SendAsync(string toEmail, string subject, string body);
    }
}
