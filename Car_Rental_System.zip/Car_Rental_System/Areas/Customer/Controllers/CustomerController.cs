using Microsoft.AspNetCore.Mvc;
using CarRentalSystemSeparation.Areas.Customer.Services;
using CarRentalSystemSeparation.Areas.Customer.ViewModels;
using CarRentalSystemSeparation.Areas.Vehicle.Services;
using CarRentalSystemSeparation.Areas.Admin.Services;
using CarRentalSystemSeparation.Areas.Admin.Repositories;
using System.Security.Claims;

namespace CarRentalSystemSeparation.Areas.Customer.Controllers
{
    [Area("Customer")]
    public class CustomerController : Controller
    {
        private readonly ICustomerService _customerService;
        private readonly IVehicleService _vehicleService;
        private readonly IBannerService _bannerService;
        private readonly IUserRepository _userRepository;

        public CustomerController(ICustomerService customerService, IVehicleService vehicleService, IBannerService bannerService, IUserRepository userRepository)
        {
            _customerService = customerService;
            _vehicleService = vehicleService;
            _bannerService = bannerService;
            _userRepository = userRepository;
        }

        public async Task<IActionResult> Index()
        {
            // Show the Home index content for authenticated customers
            var banners = await _bannerService.GetActiveBannersAsync();
            var availableVehicles = await _vehicleService.GetAvailableVehiclesAsync();
            var featuredVehicles = availableVehicles.Take(6);

            ViewBag.Banners = banners;
            ViewBag.FeaturedVehicles = featuredVehicles;

            return View("~/Views/Home/Index.cshtml", availableVehicles);
        }

        // New profile action � shows customer details or Create view prefilled when no customer exists
        public async Task<IActionResult> Profile()
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
                return Challenge();

            var user = await _userRepository.GetByEmailAsync(email);
            if (user == null)
                return Forbid();

            var customer = await _customerService.GetCustomerByUserIdAsync(user.Id);
            if (customer == null)
            {
                var vm = new CustomerViewModel
                {
                    UserId = user.Id,
                    UserName = user.FullName,
                    Email = user.Email
                };

                // Also provide ViewBag fallbacks for the view
                ViewBag.UserName = user.FullName;
                ViewBag.Email = user.Email;

                return View("Create", vm);
            }

            return View("Details", customer);
        }

        public async Task<IActionResult> Details(int id)
        {
            var customer = await _customerService.GetCustomerByIdAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        public IActionResult Create()
        {
            var viewModel = new CustomerViewModel();
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerViewModel viewModel)
        {
            if (!ModelState.IsValid)
                return View(viewModel);

            var customer = await _customerService.CreateCustomerAsync(viewModel);
            if (customer == null)
            {
                ModelState.AddModelError("", "Customer profile already exists for this user.");
                return View(viewModel);
            }

            TempData["SuccessMessage"] = "Customer profile created successfully!";
            return RedirectToAction(nameof(Details), new { id = customer.Id });
        }

        public async Task<IActionResult> Edit(int id)
        {
            var customer = await _customerService.GetCustomerByIdAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            var viewModel = new CustomerViewModel
            {
                UserId = customer.UserId,
                Phone = customer.Phone,
                Address = customer.Address,
                City = customer.City,
                State = customer.State,
                ZipCode = customer.ZipCode,
                DateOfBirth = customer.DateOfBirth,
                LicenseNumber = customer.LicenseNumber,
                LicenseExpiry = customer.LicenseExpiry,
                UserName = customer.UserName,
                Email = customer.Email
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CustomerViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            var customer = await _customerService.UpdateCustomerAsync(id, viewModel);
            if (customer == null)
            {
                return NotFound();
            }

            TempData["SuccessMessage"] = "Customer profile updated successfully!";
            return RedirectToAction(nameof(Details), new { id = customer.Id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var success = await _customerService.DeleteCustomerAsync(id);
            if (success)
            {
                TempData["SuccessMessage"] = "Customer profile deleted successfully.";
            }
            else
            {
                TempData["ErrorMessage"] = "Unable to delete customer profile.";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}