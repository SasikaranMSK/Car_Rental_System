﻿using System.ComponentModel.DataAnnotations;

namespace CarRentalSystemSeparation.Areas.Customer.DTOs
{
    public class OtpRequestDto
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Password { get; set; }
        public string Email { get; set; } = null!;
        public string Otp { get; set; } = null!;

    }
}
