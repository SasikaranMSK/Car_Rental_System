using System.ComponentModel.DataAnnotations;

namespace CarRentalSystemSeparation.Areas.Customer.ViewModels
{
    public class CustomerViewModel
    {
        [Required(ErrorMessage = "User ID is required")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        [Phone(ErrorMessage = "Please enter a valid phone number")]
        [StringLength(20, ErrorMessage = "Phone number cannot exceed 20 characters")]
        public string Phone { get; set; } = string.Empty;

        [Required(ErrorMessage = "Address is required")]
        [StringLength(200, ErrorMessage = "Address cannot exceed 200 characters")]
        public string Address { get; set; } = string.Empty;

        [Required(ErrorMessage = "City is required")]
        [StringLength(50, ErrorMessage = "City cannot exceed 50 characters")]
        public string City { get; set; } = string.Empty;

        [Required(ErrorMessage = "State is required")]
        [StringLength(50, ErrorMessage = "State cannot exceed 50 characters")]
        public string State { get; set; } = string.Empty;

        [Required(ErrorMessage = "ZIP code is required")]
        [StringLength(10, ErrorMessage = "ZIP code cannot exceed 10 characters")]
        [Display(Name = "ZIP Code")]
        public string ZipCode { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        [Display(Name = "Date of Birth")]
        public DateTime? DateOfBirth { get; set; }

        [Required(ErrorMessage = "License number is required")]
        [StringLength(50, ErrorMessage = "License number cannot exceed 50 characters")]
        [Display(Name = "License Number")]
        public string LicenseNumber { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        [Display(Name = "License Expiry")]
        public DateTime? LicenseExpiry { get; set; }

        // Read-only properties for display
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}