using AutoMapper;
using CarRentalSystemSeparation.Areas.Booking.Models;
using CarRentalSystemSeparation.Areas.Booking.DTOs;
using CarRentalSystemSeparation.Areas.Booking.ViewModels;
using CarRentalSystemSeparation.Areas.Vehicle.Repositories;
using CarRentalSystemSeparation.Common.Enums;
using CarRentalSystemSeparation.Areas.Booking.Repositories;

namespace CarRentalSystemSeparation.Areas.Booking.Services
{
     public interface IBookingService
    {
        Task<IEnumerable<BookingListDTO>> GetAllBookingsAsync();
        Task<IEnumerable<BookingListDTO>> GetUserBookingsAsync(int userId);
        Task<BookingDTO?> GetBookingByIdAsync(int id);
        Task<BookingDTO?> CreateBookingAsync(BookingViewModel viewModel, int userId);
        Task<BookingDTO?> UpdateBookingAsync(int id, BookingViewModel viewModel);
        Task<bool> CancelBookingAsync(int id);
        Task<bool> ConfirmBookingAsync(int id);
        Task<bool> CompleteBookingAsync(int id);
        Task<bool> IsVehicleAvailableAsync(int vehicleId, DateTime pickupDate, DateTime returnDate);
    }

    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _bookingRepository;
        private readonly IVehicleRepository _vehicleRepository;
        private readonly IMapper _mapper;

        public BookingService(IBookingRepository bookingRepository, IVehicleRepository vehicleRepository, IMapper mapper)
        {
            _bookingRepository = bookingRepository;
            _vehicleRepository = vehicleRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<BookingListDTO>> GetAllBookingsAsync()
        {
            var bookings = await _bookingRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<BookingListDTO>>(bookings);
        }

        public async Task<IEnumerable<BookingListDTO>> GetUserBookingsAsync(int userId)
        {
            var bookings = await _bookingRepository.GetByUserIdAsync(userId);
            return _mapper.Map<IEnumerable<BookingListDTO>>(bookings);
        }

        public async Task<BookingDTO?> GetBookingByIdAsync(int id)
        {
            var booking = await _bookingRepository.GetByIdAsync(id);
            if (booking == null)
                return null;
            return _mapper.Map<BookingDTO>(booking);
        }

        public async Task<BookingDTO?> CreateBookingAsync(BookingViewModel viewModel, int userId)
        {
            var isAvailable = await _bookingRepository.IsVehicleAvailableAsync(
                viewModel.VehicleId, viewModel.PickupDate, viewModel.ReturnDate);

            if (!isAvailable)
                return null;

            var vehicle = await _vehicleRepository.GetByIdAsync(viewModel.VehicleId);
            if (vehicle == null || vehicle.Status != VehicleStatus.Available)
                return null;

            // Replace this block in CreateBookingAsync:

            // var booking = _mapper.Map<CarRentalSystemSeparation.Areas.Booking.Models.Booking>(viewModel);
            // booking.Status = BookingStatus.Pending;
            // booking.PickupDate = viewModel.PickupDate;
            // booking.ReturnDate = viewModel.ReturnDate;
            // booking.PickupTime = viewModel.PickupTime;
            // booking.Notes = viewModel.Notes;
            // booking.TotalAmount = vehicle.PricePerDay * ((viewModel.ReturnDate.Date - viewModel.PickupDate.Date).Days + 1);
            // var createdBooking = await _bookingRepository.CreateAsync(booking);

            // With this block:

            var booking = _mapper.Map<CarRentalSystemSeparation.Areas.Booking.Models.Booking>(viewModel);
            booking.Status = BookingStatus.Pending;
            booking.PickupDate = viewModel.PickupDate;
            booking.ReturnDate = viewModel.ReturnDate;
            booking.PickupTime = viewModel.PickupTime;
            booking.Notes = viewModel.Notes;
            booking.TotalAmount = vehicle.PricePerDay * ((viewModel.ReturnDate.Date - viewModel.PickupDate.Date).Days + 1);

            // If your Booking model has a UserId property, set it here
            // booking.UserId = userId;

            var createdBooking = await _bookingRepository.CreateAsync(booking);
            return _mapper.Map<BookingDTO>(createdBooking);
        }

        public async Task<BookingDTO?> UpdateBookingAsync(int id, BookingViewModel viewModel)
        {
            var existingBooking = await _bookingRepository.GetByIdAsync(id);
            if (existingBooking is null)
                return null;

            if (existingBooking.Status != BookingStatus.Pending)
                return null;

            // Fix: You cannot access VehicleId from IBookingRepository.
            // You need to get the vehicleId from the viewModel instead.
            var vehicle = await _vehicleRepository.GetByIdAsync(viewModel.VehicleId);
            if (vehicle != null)
            {
                var totalDays = (viewModel.ReturnDate.Date - viewModel.PickupDate.Date).Days + 1;
                existingBooking.TotalAmount = vehicle.PricePerDay * totalDays;
            }

            existingBooking.PickupDate = viewModel.PickupDate;
            existingBooking.ReturnDate = viewModel.ReturnDate;
            existingBooking.PickupTime = viewModel.PickupTime;
            existingBooking.Notes = viewModel.Notes;

            var updatedBooking = await _bookingRepository.UpdateAsync(existingBooking);
            return _mapper.Map<BookingDTO>(updatedBooking);
        }

        public async Task<bool> CancelBookingAsync(int id)
        {
            var booking = await _bookingRepository.GetByIdAsync(id);
            if (booking is null)
                return false;

            if (booking.Status == BookingStatus.Cancelled || booking.Status == BookingStatus.Completed)
                return false;

            booking.Status = BookingStatus.Cancelled;
            await _bookingRepository.UpdateAsync(booking);
            return true;
        }

        public async Task<bool> ConfirmBookingAsync(int id)
        {
            var booking = await _bookingRepository.GetByIdAsync(id);
            if (booking == null || booking.Status != BookingStatus.Pending)
                return false;

            booking.Status = BookingStatus.Confirmed;
            await _bookingRepository.UpdateAsync(booking);
            return true;
        }

        public async Task<bool> CompleteBookingAsync(int id)
        {
            var booking = await _bookingRepository.GetByIdAsync(id);
            if (booking == null || booking.Status != BookingStatus.InProgress)
                return false;

            booking.Status = BookingStatus.Completed;
            await _bookingRepository.UpdateAsync(booking);
            return true;
        }

        public async Task<bool> IsVehicleAvailableAsync(int vehicleId, DateTime pickupDate, DateTime returnDate)
        {
            return await _bookingRepository.IsVehicleAvailableAsync(vehicleId, pickupDate, returnDate);
        }
    }
}