using Microsoft.AspNetCore.Mvc;
using CarRentalSystemSeparation.Areas.Booking.Services;
using CarRentalSystemSeparation.Areas.Booking.ViewModels;
using CarRentalSystemSeparation.Areas.Vehicle.Services;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using CarRentalSystemSeparation.Areas.Admin.Repositories;
using CarRentalSystemSeparation.Areas.Customer.Services;

namespace CarRentalSystemSeparation.Areas.Booking.Controllers
{
    [Area("Booking")]
    [Authorize(Roles = "Customer")]
    public class BookingController : Controller
    {
        private readonly IBookingService _bookingService;
        private readonly IVehicleService _vehicleService;
        private readonly IUserRepository _userRepository;
        private readonly ICustomerService _customerService;

        public BookingController(IBookingService bookingService, IVehicleService vehicleService, IUserRepository userRepository, ICustomerService customerService)
        {
            _bookingService = bookingService;
            _vehicleService = vehicleService;
            _userRepository = userRepository;
            _customerService = customerService;
        }

        public async Task<IActionResult> Index()
        {
            var bookings = await _bookingService.GetAllBookingsAsync();
            return View(bookings);
        }

        public async Task<IActionResult> MyBookings()
        {
            // Determine current logged-in user id from claims
            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
            {
                return Challenge();
            }

            var user = await _userRepository.GetByEmailAsync(email);
            if (user == null)
            {
                return Forbid();
            }

            // Attempt to find customer record for this user (optional)
            var customer = await _customerService.GetCustomerByUserIdAsync(user.Id);
            var userId = user.Id;

            var bookings = await _bookingService.GetUserBookingsAsync(userId);
            return View(bookings);
        }

        public async Task<IActionResult> Create(int vehicleId)
        {
            var vehicle = await _vehicleService.GetVehicleByIdAsync(vehicleId);
            if (vehicle == null)
            {
                return NotFound();
            }

            var viewModel = new BookingViewModel
            {
                VehicleId = vehicleId,
                VehicleName = vehicle.DisplayName,
                PricePerDay = vehicle.PricePerDay,
                VehicleImageUrl = vehicle.ImageUrl,
                PickupDate = DateTime.Today.AddDays(1),
                ReturnDate = DateTime.Today.AddDays(2)
            };

            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BookingViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                // Reload vehicle data for display
                var vehicle = await _vehicleService.GetVehicleByIdAsync(viewModel.VehicleId);
                if (vehicle != null)
                {
                    viewModel.VehicleName = vehicle.DisplayName;
                    viewModel.PricePerDay = vehicle.PricePerDay;
                    viewModel.VehicleImageUrl = vehicle.ImageUrl;
                }
                return View(viewModel);
            }

            // Resolve current user id from claims instead of hardcoding
            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
            {
                return Challenge();
            }

            var user = await _userRepository.GetByEmailAsync(email);
            if (user == null)
            {
                return Forbid();
            }

            var userId = user.Id;

            var booking = await _bookingService.CreateBookingAsync(viewModel, userId);
            
            if (booking == null)
            {
                ModelState.AddModelError("", "Vehicle is not available for the selected dates.");
                return View(viewModel);
            }

            TempData["SuccessMessage"] = "Booking created successfully!";
            return RedirectToAction(nameof(Details), new { id = booking.Id });
        }

        public async Task<IActionResult> Details(int id)
        {
            var booking = await _bookingService.GetBookingByIdAsync(id);
            if (booking == null)
            {
                return NotFound();
            }

            return View(booking);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id)
        {
            var success = await _bookingService.CancelBookingAsync(id);
            if (success)
            {
                TempData["SuccessMessage"] = "Booking cancelled successfully.";
            }
            else
            {
                TempData["ErrorMessage"] = "Unable to cancel booking.";
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Confirm(int id)
        {
            var success = await _bookingService.ConfirmBookingAsync(id);
            if (success)
            {
                TempData["SuccessMessage"] = "Booking confirmed successfully.";
            }
            else
            {
                TempData["ErrorMessage"] = "Unable to confirm booking.";
            }

            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Complete(int id)
        {
            var success = await _bookingService.CompleteBookingAsync(id);
            if (success)
            {
                TempData["SuccessMessage"] = "Booking completed successfully.";
            }
            else
            {
                TempData["ErrorMessage"] = "Unable to complete booking.";
            }

            return RedirectToAction(nameof(Details), new { id });
        }
    }
}