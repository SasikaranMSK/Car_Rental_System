using Microsoft.EntityFrameworkCore;
using CarRentalSystemSeparation.Common.Data;
using CarRentalSystemSeparation.Areas.Booking.Models;
using CarRentalSystemSeparation.Common.Enums;

namespace CarRentalSystemSeparation.Areas.Booking.Repositories
{
    public interface IBookingRepository
    {
        DateTime UpdatedAt { get; set; }
        DateTime CreatedAt { get; set; }
        BookingStatus Status { get; set; }
        DateTime PickupDate { get; set; }
        string PickupTime { get; set; }
        DateTime ReturnDate { get; set; }
        string Notes { get; set; }
        decimal TotalAmount { get; set; }

        Task<IEnumerable<Models.Booking>> GetAllAsync();
        Task<IEnumerable<Models.Booking>> GetByUserIdAsync(int userId);
        Task<Models.Booking?> GetByIdAsync(int id);
        Task<Models.Booking> CreateAsync(Models.Booking booking);
        Task<Models.Booking> UpdateAsync(Models.Booking booking);
        Task<bool> DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
        Task<bool> IsVehicleAvailableAsync(int vehicleId, DateTime pickupDate, DateTime returnDate);
    }

    public class BookingRepository : IBookingRepository
    {
        private readonly ApplicationDbContext _context;

        // Implement interface properties with auto-properties
        public DateTime UpdatedAt { get; set; }
        public DateTime CreatedAt { get; set; }
        public BookingStatus Status { get; set; }
        public DateTime PickupDate { get; set; }
        public string PickupTime { get; set; } = string.Empty;
        public DateTime ReturnDate { get; set; }
        public string Notes { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }

        public BookingRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Models.Booking>> GetAllAsync()
        {
            return await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Vehicle)
                .OrderByDescending(b => b.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Models.Booking>> GetByUserIdAsync(int userId)
        {
            return await _context.Bookings
                .Include(b => b.Vehicle)
                .Where(b => b.UserId == userId)
                .OrderByDescending(b => b.CreatedAt)
                .ToListAsync();
        }

        public async Task<Models.Booking?> GetByIdAsync(int id)
        {
            return await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Vehicle)
                .FirstOrDefaultAsync(b => b.Id == id);
        }

        public async Task<Models.Booking> CreateAsync(Models.Booking booking)
        {
            booking.CreatedAt = DateTime.UtcNow;
            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();
            return booking;
        }

        public async Task<Models.Booking> UpdateAsync(Models.Booking booking)
        {
            booking.UpdatedAt = DateTime.UtcNow;
            _context.Bookings.Update(booking);
            await _context.SaveChangesAsync();
            return booking;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null)
                return false;

            _context.Bookings.Remove(booking);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Bookings.AnyAsync(b => b.Id == id);
        }

        public async Task<bool> IsVehicleAvailableAsync(int vehicleId, DateTime pickupDate, DateTime returnDate)
        {
            return !await _context.Bookings.AnyAsync(b =>
                b.VehicleId == vehicleId &&
                b.Status != BookingStatus.Cancelled &&
                ((pickupDate >= b.PickupDate && pickupDate <= b.ReturnDate) ||
                 (returnDate >= b.PickupDate && returnDate <= b.ReturnDate) ||
                 (pickupDate <= b.PickupDate && returnDate >= b.ReturnDate)));
        }
    }
}