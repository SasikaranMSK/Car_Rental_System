using CarRentalSystemSeparation.Areas.Admin.Repositories;
using CarRentalSystemSeparation.Areas.Admin.Services;
using CarRentalSystemSeparation.Areas.Vehicle.Repositories;
using CarRentalSystemSeparation.Areas.Vehicle.Services;
using CarRentalSystemSeparation.Common.Data;
using CarRentalSystemSeparation.Common.Mapping;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OAuth;
using CarRentalSystemSeparation.Areas.Customer.Services;
using CarRentalSystemSeparation.Areas.Admin.Repositories;
using CarRentalSystemSeparation.Areas.Admin.Services;
using CarRentalSystemSeparation.Areas.Vehicle.Repositories;
using CarRentalSystemSeparation.Areas.Vehicle.Services;
//using NETCore.MailKit.Core;

var builder = WebApplication.CreateBuilder(args);

// ================= EMAIL SERVICE =================
builder.Services.AddScoped<IEmailService, EmailService>();

// ================= MVC CONTROLLERS =================
builder.Services.AddControllersWithViews();

// ================= DB CONTEXT =================
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// ================= AUTOMAPPER =================
builder.Services.AddAutoMapper(cfg => cfg.AddProfile<AutoMapperProfile>());

// ================= REPOSITORIES =================
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IVehicleRepository, VehicleRepository>();
builder.Services.AddScoped<IBannerRepository, BannerRepository>();
builder.Services.AddScoped<CarRentalSystemSeparation.Areas.Booking.Repositories.IBookingRepository,
                          CarRentalSystemSeparation.Areas.Booking.Repositories.BookingRepository>();
builder.Services.AddScoped<CarRentalSystemSeparation.Areas.Customer.Repositories.ICustomerRepository, 
                          CarRentalSystemSeparation.Areas.Customer.Repositories.CustomerRepository>();

//builder.Services.AddScoped<CarRentalSystemSeparation.Areas.Booking.Repositories.IRentalRepository,
//CarRentalSystemSeparation.Areas.Booking.Repositories.RentalRepository>();

// ================= SERVICES =================
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IVehicleService, VehicleService>();
builder.Services.AddScoped<IBannerService, BannerService>();
builder.Services.AddScoped<CarRentalSystemSeparation.Areas.Booking.Services.IBookingService,
                          CarRentalSystemSeparation.Areas.Booking.Services.BookingService>();
builder.Services.AddScoped<CarRentalSystemSeparation.Areas.Customer.Services.ICustomerService, 
                          CarRentalSystemSeparation.Areas.Customer.Services.CustomerService>();
//builder.Services.AddScoped<CarRentalSystemSeparation.Areas.Booking.Services.IRentalService,
//CarRentalSystemSeparation.Areas.Booking.Services.RentalService>();

// ================= AUTHENTICATION =================
builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
})
.AddCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
})

// ===== GOOGLE LOGIN =====
.AddGoogle("Google", options =>
{
    options.ClientId = builder.Configuration["Authentication:Google:ClientId"];
    options.ClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];

    options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "sub");
    options.ClaimActions.MapJsonKey(ClaimTypes.Email, "email");

    options.Events.OnCreatingTicket = ctx =>
    {
        var identity = (ClaimsIdentity)ctx.Principal.Identity;
        // You can add extra claims here if needed
        return Task.CompletedTask;
    };
})

// ===== FACEBOOK LOGIN =====
.AddFacebook("Facebook", options =>
{
    options.AppId = builder.Configuration["Authentication:Facebook:AppId"];
    options.AppSecret = builder.Configuration["Authentication:Facebook:AppSecret"];

    // Request additional fields
    options.Fields.Add("email");

    options.Events = new OAuthEvents
    {
        OnCreatingTicket = context =>
        {
            var identity = (ClaimsIdentity)context.Principal.Identity;

            // Facebook userId
            var userId = context.Principal.FindFirstValue(ClaimTypes.NameIdentifier);

            return Task.CompletedTask;
        }
    };
});

var app = builder.Build();

// ================= MIDDLEWARE =================
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

// ================= ROUTING =================
// Area routing - {area:exists} first
app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

// Default route for guest/common views
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
