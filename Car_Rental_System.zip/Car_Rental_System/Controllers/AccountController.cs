﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using CarRentalSystemSeparation.Areas.Admin.Models;
using CarRentalSystemSeparation.Common.Enums;
using CarRentalSystemSeparation.Areas.Admin.Repositories;
using CarRentalSystemSeparation.Areas.Customer.Services;
using CarRentalSystemSeparation.Areas.Customer.Models;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using CarRentalSystemSeparation.Areas.Customer.DTOs;
using Microsoft.EntityFrameworkCore;
using CarRentalSystemSeparation.Common.Data;
using NETCore.MailKit.Core;
using CarRentalSystemSeparation.Areas.Customer.ViewModels;

namespace CarRentalSystemSeparation.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserRepository _userRepository;
        private readonly ApplicationDbContext _context;
        private readonly Areas.Customer.Services.IEmailService _emailService;

        public AccountController(IUserRepository userRepository, ApplicationDbContext context, Areas.Customer.Services.IEmailService emailService)
        {
            _userRepository = userRepository;
            _context = context;
            _emailService = emailService;
        }

        // ============ NORMAL LOGIN Get ===========
        [HttpGet]
        public IActionResult Login(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        // ============ NORMAL LOGIN Post ===========
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string email, string password, bool rememberMe, string returnUrl = null)
        {
            var user = await _userRepository.GetByEmailAsync(email);

            if (user == null || !user.VerifyPassword(password))
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                ViewData["ReturnUrl"] = returnUrl;
                return View();
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.FullName),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role.ToString())
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

            // If returnUrl provided and is local, redirect to it
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }

            if (user.Role == UserRole.Admin || user.Role == UserRole.SuperAdmin)
            {
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }
            else if (user.Role == UserRole.Customer)
            {
                TempData["WelcomeMessage"] = $"Welcome back, {user.FullName}!";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        // ============ LOGOUT Post ===========
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        // ============ REGISTER Get ===========
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // ============ REGISTER Post ===========
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (string.IsNullOrEmpty(model.Email))
            {
                ModelState.AddModelError("Email", "Email is required.");
                return View(model);
            }

            // Registered Check
            var existingUser = await _userRepository.GetByEmailAsync(model.Email);
            if (existingUser != null)
            {
                TempData["Error"] = "Email already registered!";
                return View(model);
            }

            // OTP Service
            var otp = new OtpService().GenerateOtp();

            // Save OTP in DB
            var otpEntry = new OtpVerification
            {
                Email = model.Email,
                OtpCode = otp,
                ExpiryTime = DateTime.Now.AddMinutes(5),
                IsVerified = false,
            };
            _context.OtpVerifications.Add(otpEntry);
            await _context.SaveChangesAsync();

            // Send OTP in Email
            if (!string.IsNullOrEmpty(model.Email))
            {
                await _emailService.SendAsync(
                    model.Email,
                    "TIC Rentals - OTP Verification",
                    $"<h3>Your OTP is: <b>{otp}</b></h3><p>Valid for 5 minutes.</p>"
                );
            }

            // Redirect to VerifyOtp page
            return RedirectToAction("VerifyOtp", new { email = model.Email });
        }

        // ============ OTP Get ===========
        [HttpGet]
        public IActionResult VerifyOtp( string email)
        {
            return View(new OtpRequestDto { Email = email });
        }

        // ============ OTP Post ===========
        [HttpPost]
        public async Task<IActionResult> VerifyOtp(OtpRequestDto model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var otpEntry = await _context.OtpVerifications
                .Where(o => o.Email == model.Email && !o.IsVerified)
                .OrderByDescending(o => o.Id)
                .FirstOrDefaultAsync();

            if (otpEntry != null && otpEntry.OtpCode == model.Otp && otpEntry.ExpiryTime > DateTime.UtcNow)
            {
                otpEntry.IsVerified = true;
                await _context.SaveChangesAsync();


                // OTP success email
                if (!string.IsNullOrEmpty(model.Email))
                {
                    await _emailService.SendAsync(
                        model.Email,
                        "TIC Rentals - OTP Verified",
                        $"<h3>Hi!</h3><p>Your OTP has been successfully verified. You can now login to your account.</p>"
                    );
                }

                TempData["SuccessMessage"] = "OTP verified successfully! Please login.";
                return RedirectToAction("Login");
            }

            ModelState.AddModelError("", "Ivalid or expired OTP.");
            return View(model);

        }

        // ============ HASHPASSWORD ===========
        private string HashPassword(string password)
        {
            using var sha256 = System.Security.Cryptography.SHA256.Create();
            var hashedBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(hashedBytes);
        }

        // ================= GOOGLE LOGIN Get ================
        [HttpGet]
        public IActionResult LoginWithGoogle()
        {
            var properties = new AuthenticationProperties
            {
                RedirectUri = Url.Action("GoogleResponse")
            };
            return Challenge(properties, "Google");
        }

        // ================= GOOGLE LOGIN Response ================
        [HttpGet]
        public async Task<IActionResult> GoogleResponse()
        {
            // Get Google auth result
            var result = await HttpContext.AuthenticateAsync("Google");
            if (!result.Succeeded)
                return RedirectToAction("Login");

            // Extract claims
            var claims = result.Principal.Claims.ToList();
            var email = claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;

            // Check if user already exists in DB
            var user = await _userRepository.GetByEmailAsync(email);

            if (user == null)
            {
                TempData["Error"] = "This email is not registered. Please sign up first.";
                return RedirectToAction("Login", "Account");
            }

            if (!user.IsActive)
            {
                TempData["Error"] = "Your account is inactive. Contact support.";
                return RedirectToAction("Login", "Account");
            }

            // Create cookie claims (DB name & role)
            var cookieClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.FullName),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role.ToString())
            };

            var identity = new ClaimsIdentity(cookieClaims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

            if (user.Role == UserRole.Admin || user.Role == UserRole.SuperAdmin)
            {
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }
            else if (user.Role == UserRole.Customer)
            {
                TempData["WelcomeMessage"] = $"Welcome back, {user.FullName}!";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        // ================= FACEBOOK LOGIN Get ================
        [HttpGet]
        public IActionResult LoginWithFacebook()
        {
            var properties = new AuthenticationProperties
            {
                RedirectUri = Url.Action("FacebookResponse")
            };
            return Challenge(properties, "Facebook"); 
        }

        // ================= FACEBOOK LOGIN Response ================
        [HttpGet]
        public async Task<IActionResult> FacebookResponse()
        {
            // Get Facebook auth result
            var result = await HttpContext.AuthenticateAsync("Facebook");
            if (!result.Succeeded)
                return RedirectToAction("Login");

            // Extract claims
            var claims = result.Principal.Claims.ToList();
            var email = claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;

            // Check if user already exists in DB
            var user = await _userRepository.GetByEmailAsync(email);

            if (user == null)
            {
                TempData["Error"] = "This email is not registered. Please sign up first.";
                return RedirectToAction("Login", "Account");
            }

            if (!user.IsActive)
            {
                TempData["Error"] = "Your account is inactive. Contact support.";
                return RedirectToAction("Login", "Account");
            }

            // Create cookie claims (DB name & role)
            var cookieClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.FullName),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role.ToString())
            };

            var identity = new ClaimsIdentity(cookieClaims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

            if (user.Role == UserRole.Admin || user.Role == UserRole.SuperAdmin)
            {
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }
            else if (user.Role == UserRole.Customer)
            {
                TempData["WelcomeMessage"] = $"Welcome back, {user.FullName}!";
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        // ============ ACCESSDENIED ===========
        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        // ============ CHANGE PASSWORD Get ===========
        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View(new ChangePasswordViewModel());
        }

        // ============ CHANGE PASSWORD Post ===========
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
            {
                ModelState.AddModelError("", "Unable to determine current user.");
                return View(model);
            }

            var user = await _userRepository.GetByEmailAsync(email);
            if (user == null)
            {
                ModelState.AddModelError("", "User not found.");
                return View(model);
            }

            // Verify current password
            if (!user.VerifyPassword(model.CurrentPassword))
            {
                ModelState.AddModelError("CurrentPassword", "Current password is incorrect.");
                return View(model);
            }

            if (model.NewPassword != model.ConfirmNewPassword)
            {
                ModelState.AddModelError("ConfirmNewPassword", "New password and confirmation do not match.");
                return View(model);
            }

            // Update password
            user.PasswordHash = HashPassword(model.NewPassword);
            await _userRepository.UpdateAsync(user);

            TempData["SuccessMessage"] = "Password changed successfully.";
            return RedirectToAction("Profile", "Customer", new { area = "Customer" });
        }

    }
}
