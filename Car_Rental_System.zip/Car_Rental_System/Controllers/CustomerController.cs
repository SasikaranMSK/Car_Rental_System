﻿using Microsoft.AspNetCore.Mvc;

namespace CarRentalSystemSeparation.Controllers
{
    public class CustomerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
